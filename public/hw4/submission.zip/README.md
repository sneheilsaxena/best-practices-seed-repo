# README

Rachel Barrow

A13744013

<https://cse134blab4.firebaseapp.com>

I have a styled versions of customdialog.js, movies.js, and crud.html (styledcustomdialogs.js, styledmovie.js, styledcrud.html).
I followed the names shown in the writeup for styledcustomdialogs.js and styledmovie.js
